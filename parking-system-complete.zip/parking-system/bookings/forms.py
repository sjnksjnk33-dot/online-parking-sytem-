from django import forms
from django.utils import timezone
from .models import Booking, ParkingSlot


class BookingForm(forms.ModelForm):
    date = forms.DateField(widget=forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}))
    start_time = forms.TimeField(widget=forms.TimeInput(attrs={'type': 'time', 'class': 'form-control'}))
    end_time = forms.TimeField(widget=forms.TimeInput(attrs={'type': 'time', 'class': 'form-control'}))

    class Meta:
        model = Booking
        fields = ('slot', 'date', 'start_time', 'end_time')
        widgets = {
            'slot': forms.Select(attrs={'class': 'form-select'}),
        }

    def clean(self):
        cleaned = super().clean()
        start = cleaned.get('start_time')
        end = cleaned.get('end_time')
        date = cleaned.get('date')

        if start and end:
            if end <= start:
                raise forms.ValidationError('End time must be after start time.')

        if date:
            today = timezone.localdate()
            if date < today:
                raise forms.ValidationError('Booking date cannot be in the past.')

        return cleaned
