"""
Stripe webhook handler — receives and verifies Stripe events.

Register this endpoint in the Stripe Dashboard:
  Webhook URL: https://parking.webistzu.online/webhooks/stripe/
  Events to listen for: checkout.session.completed, charge.refunded
"""
import json
import stripe
from django.conf import settings
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST

from .models import Booking
from .views import _generate_qr_for_booking, _send_booking_confirmation_email


@csrf_exempt
@require_POST
def stripe_webhook(request):
    payload = request.body
    sig_header = request.META.get('HTTP_STRIPE_SIGNATURE', '')
    webhook_secret = settings.STRIPE_WEBHOOK_SECRET

    if not webhook_secret:
        # If no secret configured, trust and process (dev only)
        try:
            event = json.loads(payload)
        except Exception:
            return HttpResponse(status=400)
    else:
        try:
            event = stripe.Webhook.construct_event(payload, sig_header, webhook_secret)
        except stripe.error.SignatureVerificationError:
            return HttpResponse('Invalid signature', status=400)
        except Exception:
            return HttpResponse(status=400)

    event_type = event.get('type')

    if event_type == 'checkout.session.completed':
        session = event['data']['object']
        booking_id = session.get('metadata', {}).get('booking_id')
        if booking_id:
            try:
                booking = Booking.objects.get(pk=booking_id)
                if session.get('payment_status') == 'paid' and booking.payment_status != Booking.PAYMENT_PAID:
                    booking.payment_status = Booking.PAYMENT_PAID
                    booking.stripe_session_id = session['id']
                    booking.save(update_fields=['payment_status', 'stripe_session_id'])
                    _generate_qr_for_booking(booking)
                    _send_booking_confirmation_email(booking)
            except Booking.DoesNotExist:
                pass

    elif event_type == 'charge.refunded':
        charge = event['data']['object']
        payment_intent_id = charge.get('payment_intent')
        if payment_intent_id:
            try:
                stripe.api_key = settings.STRIPE_SECRET_KEY
                sessions = stripe.checkout.Session.list(payment_intent=payment_intent_id, limit=1)
                if sessions.data:
                    session_id = sessions.data[0].id
                    booking = Booking.objects.get(stripe_session_id=session_id)
                    booking.payment_status = Booking.PAYMENT_FAILED
                    booking.save(update_fields=['payment_status'])
            except Exception:
                pass

    return HttpResponse(status=200)
