# Deployment Guide — parking.webistzu.online

## Deploy on Render (recommended, free tier)

### 1. Push to GitHub
```bash
git add .
git commit -m "production ready"
git push origin main
```

### 2. Create a PostgreSQL database on Render
- Render Dashboard → New → PostgreSQL
- Name it `parking-db`, choose free plan
- Copy the **Internal Database URL** after it's created

### 3. Create a Web Service on Render
- New → Web Service → connect your GitHub repo
- Settings:
  - **Runtime**: Python 3
  - **Build Command**: `pip install -r requirements.txt && python manage.py collectstatic --noinput && python manage.py migrate`
  - **Start Command**: `gunicorn parking_system.wsgi --log-file -`

### 4. Set environment variables on Render
In the Web Service → Environment tab, add:

| Key | Value |
|-----|-------|
| `DJANGO_SECRET_KEY` | generate with: `python -c "import secrets; print(secrets.token_urlsafe(50))"` |
| `DJANGO_DEBUG` | `0` |
| `DJANGO_ALLOWED_HOSTS` | `parking.webistzu.online` |
| `DJANGO_CSRF_TRUSTED_ORIGINS` | `https://parking.webistzu.online` |
| `DATABASE_URL` | paste the Internal Database URL from step 2 |
| `STRIPE_PUBLIC_KEY` | `pk_live_...` |
| `STRIPE_SECRET_KEY` | `sk_live_...` |
| `STRIPE_WEBHOOK_SECRET` | get from Stripe Dashboard after setting up webhook |
| `EMAIL_HOST_USER` | your Gmail address |
| `EMAIL_HOST_PASSWORD` | Gmail App Password |
| `DEFAULT_FROM_EMAIL` | `ParkingSystem <noreply@parking.webistzu.online>` |
| `ACCOUNT_EMAIL_VERIFICATION` | `optional` |

### 5. Add your custom domain
- Render → Settings → Custom Domains → Add `parking.webistzu.online`
- In your DNS provider, add:
  ```
  Type: CNAME
  Name: parking (or @)
  Value: your-app.onrender.com
  ```
- SSL is auto-provisioned (takes ~5 minutes)

### 6. Set up Stripe Webhook
- Stripe Dashboard → Developers → Webhooks → Add endpoint
- URL: `https://parking.webistzu.online/webhooks/stripe/`
- Events: `checkout.session.completed`, `charge.refunded`
- Copy the **Signing secret** → paste as `STRIPE_WEBHOOK_SECRET` env var

### 7. Create superuser on Render
- Render → your service → Shell tab:
```bash
python manage.py createsuperuser
```

### 8. Update Google OAuth callback
- Google Cloud Console → your OAuth app → Authorized redirect URIs
- Add: `https://parking.webistzu.online/oauth/google/login/callback/`
- Django Admin → Sites → change domain to `parking.webistzu.online`

---

## Local development quick start
```bash
python -m venv .venv
source .venv/bin/activate       # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env            # fill in your keys
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

## What was added in this update
- **Booking cancellation** — users can cancel upcoming bookings from the dashboard; Stripe refund is attempted automatically
- **Stripe webhook** — `POST /webhooks/stripe/` verifies and processes payment events server-side
- **Email confirmation** — HTML email with QR code attachment sent after every successful payment
- **Production settings** — WhiteNoise for static files, PostgreSQL via DATABASE_URL, security headers, IST timezone
- **Form validation** — prevents past-date bookings and end_time before start_time
- **Razorpay keys** — wired in settings, ready to implement the payment view
